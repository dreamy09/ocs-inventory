Prerequisites :

* Mojolicious::Lite (recommended)
* Mojolicious
* Plack
* Switch
